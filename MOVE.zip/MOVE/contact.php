
<!DOCTYPE html>
<html>


<html lang="ar" dir="ltr">

      
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Almarai&display=swap" rel="stylesheet">
    <link rel="icon" href="icon.jpg" type="image/x-icon">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="cstyle.css">  
</head>

    <body>

<header>
       
        <a class="logo" href="home.html" ><span id="logo-text">M<video  class="logo" id="myVideo" width="70px" height=70px" muted loop><source src="cube-in-circle.mp4"></video>VE</span></a>
        <nav class="navigation">
        
            <a href="home.php">Home</a>
            <a href="Membership.php">Membership</a>
            <a href="contact.php">Contact Us</a>
        
        </nav>
   
    </header>


        <section class="ftco-section">
        <div class="container">
        <div class="row justify-content-center">
        <div class="col-md-6 text-center mb-5">
        <h2 class="heading-section">Contact us</h2>
        </div>
        </div>
        <div class="row justify-content-center">
        <div class="col-md-12">
        <div class="wrapper">
        <div class="row no-gutters">
            <div class="col-lg-4 col-md-5 d-flex align-items-stretch">
                <div class="info-wrap bg-primary w-100 p-md-5 p-4">
                <h3>Contact info</h3>
                <p class="mb-4"></p>
              
               
                <div class="dbox w-100 d-flex align-items-center">
                <div class="icon d-flex align-items-center justify-content-center">
                <span class="fa fa-paper-plane"></span>
                </div>
                <div class="text pl-3">
                <p><span>Email</span> <br />move@</span>gmail.com</a></p>
                </div>
                </div>
                <div class="dbox w-100 d-flex align-items-center">
                <div class="icon d-flex align-items-center justify-content-center">
                <span class="fa fa-globe"></span>
                </div>
                <div class="text pl-3">
                <p><span>Website</span><br /> <a href="#">move.com</a></p>
                </div>
                </div>
                <div class="dbox w-100 d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <a href="https://www.youtube.com/"><span class="fa fa-youtube"></span></a>
                    </div>
                    <div class="icon d-flex align-items-center justify-content-center">
                        <a href="https://www.twitter.com/"><span class="fa fa-twitter"></span></a>
                        </div>
                        <div class="icon d-flex align-items-center justify-content-center">
                            <a href="https://www.linkedin.com/">  <span class="fa fa-linkedin"></span></a>
                            </div>
                            <div class="icon d-flex align-items-center justify-content-center">
                                <a href="https://www.instagram.com/"><span class="fa fa-instagram"></span></a>
                                </div>
                    </div>
                </div>
                </div>
        <div class="col-lg-8 col-md-7 order-md-last d-flex align-items-stretch">
        <div class="contact-wrap w-100 p-md-5 p-4">
        <h3 class="mb-4">Contact us</h3>
       
        <form method="POST">
        <div class="row">
<div class="col-md-6">
        <div class="form-group">
        <input type="text" class="form-control" name="name" id="name" placeholder="Full name" required>
        </div>
        </div>

        <div class="col-md-6">
        <div class="form-group">
        <input type="text" class="form-control" name="address" id="address" placeholder="Address" required>
        </div>
        </div>
        
       

        
            <div class="col-md-6">
            <div class="form-group">
            <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
            </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone number" required>
                </div>
                </div>
        <div class="col-md-12">
        <div class="form-group">
        <textarea name="message" class="form-control" id="message" cols="30" rows="4" placeholder="message" required></textarea>
        </div>
        </div>
        <div class="col-md-12">
        <div class="form-group">
        <input type="submit" value="send" class="btn btn-primary">
        <div class="submitting"></div>
        </div>
        </div>
        </div>
        </form>
        </div>
        </div>
  
        </div>
        </div>
        </div>
        </div>
        <br />
        <div class="row">
            <div class="col-sm-4 ">
                <div class="card text-center">
                <div class="card-body">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <h1> <span class="fa fa-hourglass-start"></span></h1>
                         </div>
                  <h5 class="card-title">response time </h5>
                  <p class="card-text">60 minutes</p>
                 
                </div>
              </div>
            </div><br /><br />
            <div class="col-sm-4">
                <div class="card text-center">
                  <div class="card-body">
                    <div class="icon d-flex align-items-center justify-content-center">
                       <h1> <span class="fa fa-repeat"></span></h1>
                        </div>
                    <h5 class="card-title">Alternative service channels</h5>
                    <p class="card-text"> &nbsp</p>
                  
                  </div>
                </div>
              </div><br /><br />
            <div class="col-sm-4">
                <div class="card text-center">
                <div class="card-body">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <h1> <span class="fa fa-clock-o"></span></h1>
                         </div>
                  <h5 class="card-title">Working hours</h5>
                  <p class="card-text">24 hours</p>
             
                </div>
              </div>
            </div><br />
          </div>
        </div>


    
        </section>





        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
		   



<footer class="footer">
    <a href="https://goo.gl/maps/CDJ3UKZhva5A2X327" class="location"><i class="fa-solid fa-location-dot"></i> Saudi Arabia, Alahssa</a>
    <div class="social-icons">
        <a href="https://www.linkedin.com"><i class="fa-brands fa-linkedin "></i></a>
        <a href="https://twitter.com"><i class="fa-brands fa-twitter"></i></a>
        <a href="https://www.instagram.com"><i class="fa-brands fa-instagram"></i></a>
        <a href="mailto:MOVE@gym.org.sa"><i class="fa-solid fa-envelope "></i></a>
    </div>
   
    <p class="copyright">© MOVE, Inc.</p>
    </footer>
  
    <script>
        var video = document.getElementById("myVideo");
        
        video.addEventListener('mouseover', function(){
            this.play();
        });
        
        video.addEventListener('mouseout', function(){
            this.pause();
        });
        </script>





 </body>
</html>

</html>
