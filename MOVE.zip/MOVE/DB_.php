

<?php

if(isset($_POST['Regbtn'])){
    
    $name = $_POST['name'];
    $username = $_POST['user'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $pwd = $_POST['pwd'];
    $date = $_POST['date'];
    $gender = $_POST['gender'];
    $plan = $_POST['plan'];
    
    $conn = new mysqli('localhost','root','', 'Move');
    if ($conn->connect_error) {
        die('Connection Failed: ' . $conn->connect_error);
    }
    
    $stmt = $conn->prepare("INSERT INTO form (name, user, email, pwd, number, date, gender, plan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        die('Error: ' . mysqli_error($conn));
    }
    
    if (!$stmt->bind_param("ssssssss", $name, $username, $email, $pwd, $number, $date, $gender, $plan)) {
        die('Error: ' . mysqli_error($conn));
    }
    
    if (!$stmt->execute()) {
        die('Error: ' . mysqli_error($conn));
    }
    
    echo "Registration Successful";
    $stmt->close();
    $conn->close();
    
    

}


?>



